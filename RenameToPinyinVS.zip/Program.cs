using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using TinyPinyin;

class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        using var dlg = new FolderBrowserDialog();
        dlg.Description = "选择要批量重命名的文件夹";
        if (dlg.ShowDialog() != DialogResult.OK) return;
        foreach (var file in Directory.GetFiles(dlg.SelectedPath))
        {
            var dir = Path.GetDirectoryName(file)!;
            var stem = Path.GetFileNameWithoutExtension(file);
            var ext = Path.GetExtension(file);
            var newStem = AddPinyin(stem);
            var target = Path.Combine(dir,newStem+ext);
            int i=1;
            while(File.Exists(target) && !target.Equals(file,StringComparison.OrdinalIgnoreCase))
                target=Path.Combine(dir,$"{newStem}_{i++}{ext}");
            if(target!=file) File.Move(file,target);
        }
        MessageBox.Show("完成");
    }

    static string AddPinyin(string s)
    {
        var sb=new StringBuilder();
        int i=0;
        while(i<s.Length){
            if(s[i]>=0x4e00 && s[i]<=0x9fff){
                int j=i;
                while(j<s.Length && s[j]>=0x4e00 && s[j]<=0x9fff) j++;
                var cn=s.Substring(i,j-i);
                sb.Append(cn).Append("_").Append(PinyinHelper.GetPinyin(cn,""));
                i=j;
            } else {
                sb.Append(s[i]);
                i++;
            }
        }
        return sb.ToString();
    }
}
